import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import {
  Cpu,
  Wifi,
  Server,
  DatabaseBackup,
  MonitorSmartphone,
  ShieldCheck,
  BrainCircuit,
  Menu,
  X,
  ArrowUpRight,
  Mail,
  Phone,
  MapPin,
} from "lucide-react";
import medalAsset from "@/assets/tly2-medal.jpg.asset.json";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "TLY² | Assessoria e Soluções em TI" },
      {
        name: "description",
        content:
          "TLY² — Assessoria e Soluções em TI. Suporte técnico em Araras e região e atendimento remoto.",
      },
      { property: "og:title", content: "TLY² | Assessoria e Soluções em TI" },
      {
        property: "og:description",
        content:
          "Assessoria e soluções em TI para manter seus equipamentos, sua rede e seu negócio funcionando.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const WHATSAPP_URL =
  "https://wa.me/5519999589078?text=Ol%C3%A1%2C%20quero%20conversar%20sobre%20suporte%20de%20TI";

const services = [
  {
    icon: Cpu,
    tag: "01 — SUPORTE",
    title: "Especialista em hardware",
    desc: "Diagnóstico de falhas, manutenção e atualização de componentes de computadores, notebooks e servidores, além de configuração e suporte para o dia a dia.",
  },
  {
    icon: Wifi,
    tag: "02 — CONECTIVIDADE",
    title: "Redes e Wi-Fi",
    desc: "Configuração de roteadores, switches e redes locais para conectar seus equipamentos com organização.",
  },
  {
    icon: Server,
    tag: "03 — INFRAESTRUTURA",
    title: "Servidores, cloud e virtualização",
    desc: "Administração de Windows Server e Active Directory, ambientes VMware e Hyper-V e apoio a projetos em Oracle Cloud e IBM Cloud.",
  },
  {
    icon: DatabaseBackup,
    tag: "04 — DADOS",
    title: "Backup e recuperação",
    desc: "Planejamento de cópias de segurança e apoio à recuperação de dados, conforme as condições do ambiente.",
  },
  {
    icon: MonitorSmartphone,
    tag: "05 — À DISTÂNCIA",
    title: "Atendimento remoto",
    desc: "Suporte pela internet, com seu acompanhamento e autorização, para situações que permitem atendimento a distância.",
  },
  {
    icon: ShieldCheck,
    tag: "06 — ASSESSORIA",
    title: "Assessoria e compliance de TI",
    desc: "Avaliação da infraestrutura, gestão de atualizações e vulnerabilidades e planejamento de mudanças, com foco em conformidade, continuidade e uso eficiente dos recursos.",
  },
  {
    icon: BrainCircuit,
    tag: "07 — INTELIGÊNCIA ARTIFICIAL",
    title: "IA aplicada a projetos e redes",
    desc: "Inteligência artificial no desenvolvimento de projetos e na otimização de redes internas: automatizar tarefas, ampliar a autonomia da operação, melhorar o desempenho e reduzir custos. PowerShell, Python e Shell complementam as soluções de automação.",
  },
];

const skills = [
  "Especialista em hardware",
  "IA aplicada a projetos",
  "Windows Server",
  "Redes",
  "VMware",
  "Active Directory",
  "Backup",
  "Compliance",
  "PowerShell",
  "Cloud",
];

function Header() {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <header className="fixed inset-x-0 top-0 z-50 border-b border-border/60 bg-background/70 backdrop-blur-xl">
      <nav className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5 sm:px-8">
        <a href="#top" className="font-display text-2xl font-bold tracking-tight">
          TLY<span className="text-primary text-glow">²</span>
        </a>

        <div className="hidden items-center gap-8 text-sm text-muted-foreground md:flex">
          <a href="#servicos" className="transition-colors hover:text-foreground">
            Serviços
          </a>
          <a href="#sobre" className="transition-colors hover:text-foreground">
            Sobre
          </a>
          <a
            href={WHATSAPP_URL}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-1.5 rounded-full border border-primary/40 bg-primary/10 px-4 py-2 font-medium text-primary transition-all hover:bg-primary/20"
          >
            Fale com a TLY² <ArrowUpRight className="h-4 w-4" />
          </a>
        </div>

        <button
          type="button"
          aria-label={open ? "Fechar menu" : "Abrir menu"}
          onClick={() => setOpen((v) => !v)}
          className="grid h-10 w-10 place-items-center rounded-lg border border-border text-foreground md:hidden"
        >
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </nav>

      {open && (
        <div className="border-t border-border/60 bg-background/95 backdrop-blur-xl md:hidden">
          <div className="flex flex-col gap-1 px-5 py-4">
            <a
              href="#servicos"
              onClick={() => setOpen(false)}
              className="rounded-lg px-3 py-3 text-base text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
            >
              Serviços
            </a>
            <a
              href="#sobre"
              onClick={() => setOpen(false)}
              className="rounded-lg px-3 py-3 text-base text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
            >
              Sobre
            </a>
            <a
              href={WHATSAPP_URL}
              target="_blank"
              rel="noreferrer"
              className="mt-2 inline-flex items-center justify-center gap-2 rounded-xl bg-primary px-4 py-3.5 font-semibold text-primary-foreground"
            >
              Fale com a TLY² <ArrowUpRight className="h-4 w-4" />
            </a>
          </div>
        </div>
      )}
    </header>
  );
}

function Hero() {
  return (
    <section id="top" className="relative overflow-hidden pt-16">
      <div className="grid-bg pointer-events-none absolute inset-0" aria-hidden="true" />
      <div
        className="pointer-events-none absolute -top-32 left-1/2 h-96 w-[42rem] max-w-[120vw] -translate-x-1/2 rounded-full bg-primary/15 blur-[120px]"
        aria-hidden="true"
      />

      <div className="relative mx-auto grid max-w-6xl gap-12 px-5 py-16 sm:px-8 md:grid-cols-[1.3fr_1fr] md:items-center md:py-28">
        <div>
          <span className="inline-flex items-center gap-2 rounded-full border border-primary/40 bg-primary/10 px-4 py-1.5 font-mono text-[11px] uppercase tracking-[0.2em] text-primary">
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-primary" />
            Araras e região · Suporte remoto
          </span>

          <h1 className="mt-6 font-display text-5xl font-bold leading-[1.05] tracking-tight sm:text-6xl md:text-7xl">
            Sua tecnologia.
            <br />
            <span className="text-primary text-glow">Bem cuidada.</span>
          </h1>

          <p className="mt-6 max-w-xl text-lg leading-relaxed text-muted-foreground">
            Assessoria e soluções em TI para manter seus equipamentos, sua rede
            e seu negócio funcionando.
          </p>

          <div className="mt-8 flex flex-col gap-4 sm:flex-row sm:items-center">
            <a
              href={WHATSAPP_URL}
              target="_blank"
              rel="noreferrer"
              className="animate-pulse-ring inline-flex items-center justify-center gap-2 rounded-xl bg-primary px-6 py-4 font-semibold text-primary-foreground transition-transform hover:-translate-y-0.5"
            >
              Conversar pelo WhatsApp <ArrowUpRight className="h-4 w-4" />
            </a>
            <a
              href="#servicos"
              className="inline-flex items-center justify-center gap-2 rounded-xl border border-border px-6 py-4 font-medium text-foreground transition-colors hover:bg-accent"
            >
              Conheça os serviços
            </a>
          </div>
        </div>

        <div className="animate-float-slow glass-panel relative overflow-hidden rounded-2xl p-6 shadow-2xl">
          <div
            className="animate-scanline pointer-events-none absolute inset-x-0 h-24 bg-gradient-to-b from-transparent via-primary/10 to-transparent"
            aria-hidden="true"
          />
          <div className="flex items-center gap-2 border-b border-border pb-4 font-mono text-xs text-muted-foreground">
            <span className="h-2 w-2 rounded-full bg-primary" />
            <span className="h-2 w-2 rounded-full bg-primary/50" />
            <span className="h-2 w-2 rounded-full bg-primary/25" />
            <span className="ml-auto">tly2://console</span>
          </div>
          <div className="py-6 font-display text-6xl font-bold tracking-tighter text-primary text-glow sm:text-7xl">
            TLY²
          </div>
          <ul className="font-mono text-sm leading-8 text-muted-foreground">
            <li className="border-b border-border/60">
              <span className="mr-2 text-primary">↗</span>hardware &amp; redes
            </li>
            <li className="border-b border-border/60">
              <span className="mr-2 text-primary">↗</span>cloud &amp; virtualização
            </li>
            <li className="border-b border-border/60">
              <span className="mr-2 text-primary">↗</span>backup &amp; compliance
            </li>
            <li>
              <span className="mr-2 text-primary">↗</span>IA &amp; automação
            </li>
          </ul>
        </div>
      </div>

      <div className="relative border-y border-border/60 bg-card/40">
        <div className="mx-auto grid max-w-6xl gap-4 px-5 py-6 text-sm text-muted-foreground sm:grid-cols-3 sm:px-8">
          <div>
            <strong className="font-display text-xl text-foreground">16+ anos</strong>
            <br />
            de experiência em TI
          </div>
          <div>
            <strong className="font-display text-xl text-foreground">Presencial e remoto</strong>
            <br />
            atendimento flexível
          </div>
          <div>
            <strong className="font-display text-xl text-foreground">Pessoas e empresas</strong>
            <br />
            soluções sob medida
          </div>
        </div>
      </div>
    </section>
  );
}

function Services() {
  return (
    <section id="servicos" className="mx-auto max-w-6xl scroll-mt-20 px-5 py-16 sm:px-8 md:py-24">
      <p className="font-mono text-xs uppercase tracking-[0.25em] text-primary">
        01 / Como podemos ajudar
      </p>
      <h2 className="mt-4 font-display text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">
        TI que acompanha
        <br />
        a sua necessidade.
      </h2>

      <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {services.map((s) => (
          <article
            key={s.tag}
            className="glass-panel group rounded-2xl p-6 transition-all hover:-translate-y-1 hover:border-primary/50"
          >
            <div className="flex items-center justify-between">
              <s.icon className="h-7 w-7 text-primary" />
              <span className="font-mono text-[11px] tracking-wider text-muted-foreground">
                {s.tag}
              </span>
            </div>
            <h3 className="mt-5 font-display text-lg font-semibold">{s.title}</h3>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{s.desc}</p>
          </article>
        ))}
      </div>
    </section>
  );
}

function About() {
  return (
    <section id="sobre" className="border-t border-border/60 bg-card/30">
      <div className="mx-auto grid max-w-6xl gap-10 px-5 py-16 sm:px-8 md:grid-cols-[1fr_1.3fr] md:py-24">
        <div>
          <p className="font-mono text-xs uppercase tracking-[0.25em] text-primary">
            02 / Quem está por trás
          </p>
          <h2 className="mt-4 font-display text-3xl font-bold tracking-tight sm:text-4xl">
            Experiência para cuidar do que conecta você.
          </h2>
        </div>

        <div>
          <p className="leading-relaxed text-muted-foreground">
            À frente da TLY² está <strong className="text-foreground">Tiago Denardi</strong>,
            pós-graduado em Arquitetura e Infraestrutura de TI e especialista em hardware, com mais
            de 16 anos de experiência e trajetória na IBM Brasil e na Kyndryl Brasil. Sua atuação
            reúne sustentação de ambientes corporativos, compliance, gestão de mudanças, cloud e
            virtualização, com participação em projetos de migração, automação e otimização de
            custos e desempenho.
          </p>
          <p className="mt-4 leading-relaxed text-muted-foreground">
            Graduado em Administração de Redes de Computadores pela Fundação Hermínio Ometto (FHO),
            e pós-graduado em Arquitetura e Infraestrutura de TI pela CENES. Essa base técnica
            orienta um atendimento próximo, com explicações claras e soluções adequadas à realidade
            de cada cliente.
          </p>

          <div className="mt-6 flex flex-wrap gap-2">
            {skills.map((skill) => (
              <span
                key={skill}
                className="rounded-full border border-border bg-card/60 px-3.5 py-1.5 text-xs text-muted-foreground"
              >
                {skill}
              </span>
            ))}
          </div>

          <p className="mt-6 text-sm text-muted-foreground">
            Formação e capacitação em Oracle Cloud, IBM Cloud, Microsoft Azure e hardware
            corporativo.
          </p>
        </div>
      </div>
    </section>
  );
}

function Contact() {
  return (
    <section className="mx-auto max-w-6xl px-5 py-16 sm:px-8 md:py-24">
      <div className="glass-panel relative overflow-hidden rounded-3xl p-8 sm:p-12">
        <div
          className="pointer-events-none absolute -right-24 -top-24 h-64 w-64 rounded-full bg-primary/20 blur-[80px]"
          aria-hidden="true"
        />
        <p className="font-mono text-xs uppercase tracking-[0.25em] text-primary">
          03 / Vamos conversar
        </p>
        <h2 className="mt-4 font-display text-3xl font-bold tracking-tight sm:text-4xl">
          Como podemos ajudar você?
        </h2>
        <p className="mt-3 max-w-lg text-muted-foreground">
          Conte o que precisa e consulte as opções de atendimento.
        </p>

        <div className="mt-8 grid gap-3 text-sm text-muted-foreground">
          <span className="inline-flex items-center gap-2.5">
            <MapPin className="h-4 w-4 shrink-0 text-primary" /> Araras e região · Suporte remoto
          </span>
          <a
            href="mailto:tiago.egidio.denardi@outlook.com"
            className="inline-flex items-center gap-2.5 break-all transition-colors hover:text-foreground"
          >
            <Mail className="h-4 w-4 shrink-0 text-primary" /> tiago.egidio.denardi@outlook.com
          </a>
          <a
            href="tel:+5519999589078"
            className="inline-flex items-center gap-2.5 transition-colors hover:text-foreground"
          >
            <Phone className="h-4 w-4 shrink-0 text-primary" /> (19) 99958-9078
          </a>
        </div>

        <a
          href={WHATSAPP_URL}
          target="_blank"
          rel="noreferrer"
          className="mt-8 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-primary px-6 py-4 font-semibold text-primary-foreground transition-transform hover:-translate-y-0.5 sm:w-auto"
        >
          Solicitar atendimento <ArrowUpRight className="h-4 w-4" />
        </a>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="border-t border-border/60">
      <div className="mx-auto flex max-w-6xl flex-col gap-2 px-5 py-8 text-sm text-muted-foreground sm:flex-row sm:items-center sm:justify-between sm:px-8">
        <span>
          <strong className="font-display text-foreground">TLY²</strong> — Assessoria e Soluções em
          TI
        </span>
        <span>Araras · São Paulo</span>
      </div>
    </footer>
  );
}

function Index() {
  return (
    <div className="relative min-h-screen bg-background font-body text-foreground antialiased">
      <div
        aria-hidden="true"
        className="watermark-bg pointer-events-none fixed inset-0 z-0 select-none"
      >
        <img
          src={medalAsset.url}
          alt=""
          className="h-full w-full object-contain opacity-[0.07] mix-blend-screen sm:opacity-[0.09]"
        />
      </div>
      <Header />
      <main className="relative z-10">
        <Hero />
        <Services />
        <About />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}
