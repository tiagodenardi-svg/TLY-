# Roadmap

- [ ] Seção final: emblema TLY² com luz varrendo cada detalhe (em andamento)
- [ ] Preparar download do site (ZIP do código-fonte) em Files
